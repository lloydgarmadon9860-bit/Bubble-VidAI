package cz.bubble.vidai;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final String COMPAT_PENDING = "compatPending";
    private static final String HOST = "bubblevidai.local";
    private static final String ORIGIN = "https://" + HOST;
    private static final int PICK_FILES = 42;
    private final Map<String, Uri> previewSources = new ConcurrentHashMap<>();
    private final CompatDownload compat = new CompatDownload();
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private ProjectStore project;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        project = new ProjectStore(this);
        var prefs = getSharedPreferences("downloads", MODE_PRIVATE);
        String abandoned = prefs.getString(COMPAT_PENDING, "");
        if (!abandoned.isEmpty()) {
            MediaFiles.deletePending(getContentResolver(), Uri.parse(abandoned));
            prefs.edit().remove(COMPAT_PENDING).apply();
        }
        web = new WebView(this);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((view, insets) -> {
            var bars = Build.VERSION.SDK_INT >= 30
                    ? insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout())
                    : android.graphics.Insets.of(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                            insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new StudioBridge(), "VidAI");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!"https".equals(url.getScheme()) || !HOST.equals(url.getHost())) return empty(403, "Forbidden");
                String path = url.getPath();
                if (path == null) return empty(404, "Not Found");
                if (path.startsWith("/video/")) {
                    Uri media = previewSources.get(url.getLastPathSegment());
                    return media == null ? empty(404, "Not Found") : mediaResponse(media, request);
                }
                if (!path.matches("/[a-z0-9-]+\\.(html|js|png)")) return empty(404, "Not Found");
                try {
                    String mime = path.endsWith(".png") ? "image/png"
                            : path.endsWith(".js") ? "text/javascript" : "text/html";
                    return new WebResourceResponse(mime, path.endsWith(".png") ? null : "UTF-8",
                            200, "OK", Map.of("Content-Security-Policy",
                            "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                                    + "media-src 'self' blob:; object-src 'none'; frame-src 'none'"),
                            getAssets().open(path.substring(1)));
                } catch (IOException e) {
                    return empty(404, "Not Found");
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                String[] types = params.getAcceptTypes();
                pickingVideo = types != null && java.util.Arrays.stream(types)
                        .anyMatch(type -> type != null && type.startsWith("video/"));
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    boolean oneType = types != null && types.length == 1 && !types[0].isEmpty();
                    intent.setType(oneType ? types[0] : "*/*");
                    if (types != null && types.length > 1) intent.putExtra(Intent.EXTRA_MIME_TYPES, types);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, PICK_FILES);
                } catch (RuntimeException e) {
                    chooser = null;
                    callback.onReceiveValue(null);
                    toast("Výběr souborů není dostupný.");
                }
                return true;
            }
        });
        web.loadUrl(ORIGIN + "/index.html");
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILES || chooser == null) return;
        ValueCallback<Uri[]> callback = chooser;
        chooser = null;
        ArrayList<Uri> uris = new ArrayList<>();
        if (result == RESULT_OK && data != null) {
            ClipData clips = data.getClipData();
            if (clips == null && data.getData() != null) uris.add(data.getData());
            if (clips != null) {
                for (int i = 0; i < clips.getItemCount(); i++) {
                    Uri uri = clips.getItemAt(i).getUri();
                    if (uri != null) uris.add(uri);
                }
            }
        }
        boolean videoPicker = pickingVideo;
        pickingVideo = false;
        if (videoPicker && !uris.isEmpty()) {
            JSONArray files = new JSONArray();
            for (Uri uri : uris) {
                boolean retained = false;
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    retained = true;
                } catch (SecurityException ignored) {}
                try {
                    files.put(describe(uri).put("retained", retained));
                } catch (JSONException | RuntimeException ignored) {}
            }
            callback.onReceiveValue(null);
            if (files.length() > 0) web.evaluateJavascript("Studio.importNative(" + files + ")", null);
            else toast("Vybrané video nelze otevřít.");
        } else {
            callback.onReceiveValue(uris.isEmpty() ? null : uris.toArray(new Uri[0]));
            if (result == RESULT_OK && uris.isEmpty()) toast("Výběr nevrátil žádný soubor.");
        }
    }

    private boolean pickingVideo;

    private JSONObject describe(Uri uri) throws JSONException {
        if (!"content".equals(uri.getScheme())) throw new IllegalArgumentException("Neplatný zdroj.");
        String name = "Video";
        try (var cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && cursor.getString(0) != null) name = cursor.getString(0);
        }
        String key = previewSources.entrySet().stream()
                .filter(entry -> entry.getValue().equals(uri)).map(Map.Entry::getKey)
                .findFirst().orElseGet(() -> UUID.randomUUID().toString());
        previewSources.put(key, uri);
        return new JSONObject().put("uri", uri.toString()).put("name", name).put("url", ORIGIN + "/video/" + key);
    }

    private WebResourceResponse mediaResponse(Uri uri, WebResourceRequest request) {
        String mime;
        try { mime = getContentResolver().getType(uri); }
        catch (RuntimeException e) { return empty(404, "Not Found"); }
        if (mime == null || !mime.startsWith("video/")) mime = "video/mp4";
        String range = null;
        for (Map.Entry<String, String> header : request.getRequestHeaders().entrySet()) {
            if (header.getKey().equalsIgnoreCase("Range")) range = header.getValue();
        }
        try {
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return empty(404, "Not Found");
            ParcelFileDescriptor.AutoCloseInputStream stream = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            long size = pfd.getStatSize();
            Map<String, String> headers = new HashMap<>();
            if (size >= 0) {
                headers.put("Accept-Ranges", "bytes");
                headers.put("Content-Length", Long.toString(size));
            }
            if ("HEAD".equals(request.getMethod())) {
                stream.close();
                return new WebResourceResponse(mime, null, 200, "OK", headers, new ByteArrayInputStream(new byte[0]));
            }
            if (range == null || size < 0) return new WebResourceResponse(mime, null, 200, "OK", headers, stream);
            ByteRange part = ByteRange.parse(range, size);
            if (part == null) {
                stream.close();
                return new WebResourceResponse(mime, null, 416, "Range Not Satisfiable",
                        Map.of("Content-Range", "bytes */" + size), new ByteArrayInputStream(new byte[0]));
            }
            try {
                stream.getChannel().position(part.start());
            } catch (IOException e) {
                stream.close();
                throw e;
            }
            headers.put("Content-Range", "bytes " + part.start() + "-" + part.end() + "/" + size);
            headers.put("Content-Length", Long.toString(part.length()));
            return new WebResourceResponse(mime, null, 206, "Partial Content", headers,
                    new BoundedStream(stream, part.length()));
        } catch (IOException | RuntimeException e) {
            return empty(404, "Not Found");
        }
    }

    private static WebResourceResponse empty(int code, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", code, reason,
                Map.of(), new ByteArrayInputStream(new byte[0]));
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    @Override protected void onStop() {
        web.evaluateJavascript("Studio.onBackground()", null);
        super.onStop();
    }

    @Override protected void onDestroy() {
        compat.abort();
        if (chooser != null) chooser.onReceiveValue(null);
        web.destroy();
        super.onDestroy();
    }

    public final class StudioBridge {
        @JavascriptInterface public String restore() {
            JSONObject saved = project.load();
            try {
                JSONArray old = saved.optJSONArray("media");
                JSONArray files = new JSONArray();
                if (old != null) for (int i = 0; i < old.length(); i++) {
                    Uri uri = Uri.parse(old.getString(i));
                    try {
                        boolean retained = getContentResolver().getPersistedUriPermissions().stream()
                                .anyMatch(permission -> permission.isReadPermission() && permission.getUri().equals(uri));
                        if (!retained) continue;
                        try (var descriptor = getContentResolver().openFileDescriptor(uri, "r")) {
                            if (descriptor != null) files.put(describe(uri).put("retained", true).put("index", i));
                        } catch (IOException ignored) {}
                    } catch (RuntimeException ignored) {}
                }
                saved.put("files", files);
                saved.put("logo", project.logoData());
            } catch (JSONException ignored) {}
            return saved.toString();
        }
        @JavascriptInterface public boolean save(String state) {
            try {
                project.save(state);
                JSONArray media = new JSONObject(state).optJSONArray("media");
                if (media != null) {
                    var active = new java.util.HashSet<Uri>();
                    for (int i = 0; i < media.length(); i++) active.add(Uri.parse(media.getString(i)));
                    previewSources.entrySet().removeIf(entry -> !active.contains(entry.getValue()));
                    for (var permission : getContentResolver().getPersistedUriPermissions()) {
                        if (permission.isReadPermission() && !active.contains(permission.getUri())) {
                            getContentResolver().releasePersistableUriPermission(
                                    permission.getUri(), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        }
                    }
                }
                return true;
            }
            catch (Exception e) { return false; }
        }
        @JavascriptInterface public boolean saveLogo(String png) {
            try { project.saveLogo(png); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface public void export(String job) {
            runOnUiThread(() -> {
                try {
                    ExportService.prepare(MainActivity.this, job);
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                            && !getPreferences(MODE_PRIVATE).getBoolean("notificationAsked", false)) {
                        getPreferences(MODE_PRIVATE).edit().putBoolean("notificationAsked", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
                    }
                } catch (Exception e) {
                    ExportService.rejected(job, e);
                }
            });
        }

        @JavascriptInterface public String status() { return ExportService.snapshot(MainActivity.this); }
        @JavascriptInterface public void cancel() { ExportService.requestCancel(); }
        @JavascriptInterface public void open(String output) {
            runOnUiThread(() -> {
                Uri uri = Uri.parse(output);
                if (!"content".equals(uri.getScheme()) || !"media".equals(uri.getAuthority())
                        || !uri.getPath().contains("/downloads/")) return;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
                } catch (RuntimeException e) {
                    toast("Video najdeš ve Stažených souborech → Bubble VidAI.");
                }
            });
        }

        @JavascriptInterface public boolean beginCompat(String name, String mime) { return compat.begin(name, mime); }
        @JavascriptInterface public boolean chunkCompat(String data) { return compat.chunk(data); }
        @JavascriptInterface public String endCompat() { return compat.end(); }
        @JavascriptInterface public void abortCompat() { compat.abort(); }
    }

    private final class CompatDownload {
        private Uri uri;
        private OutputStream output;

        synchronized boolean begin(String name, String mime) {
            if (uri != null) return false;
            if (!"video/mp4".equals(mime) && !"video/webm".equals(mime)) return false;
            try {
                String file = name.replaceAll("[^\\p{L}\\p{N} _.-]", "_");
                file = file.substring(0, Math.min(file.length(), 120));
                uri = MediaFiles.openDownload(MainActivity.this, file, mime);
                getSharedPreferences("downloads", MODE_PRIVATE).edit().putString(COMPAT_PENDING, uri.toString()).commit();
                output = getContentResolver().openOutputStream(uri);
                if (output == null) throw new IOException("Úložiště není dostupné.");
                return true;
            } catch (RuntimeException | IOException e) {
                abort();
                return false;
            }
        }

        synchronized boolean chunk(String base64) {
            if (output == null || base64.length() > 800000) return false;
            try {
                output.write(android.util.Base64.decode(base64, android.util.Base64.DEFAULT));
                return true;
            } catch (RuntimeException | IOException e) {
                abort();
                return false;
            }
        }

        synchronized String end() {
            if (output == null) return "";
            try {
                output.close();
                MediaFiles.publish(getContentResolver(), uri);
                getSharedPreferences("downloads", MODE_PRIVATE).edit().remove(COMPAT_PENDING).apply();
                String result = uri.toString();
                output = null;
                uri = null;
                return result;
            } catch (RuntimeException | IOException e) {
                abort();
                return "";
            }
        }

        synchronized void abort() {
            try {
                if (output != null) output.close();
            } catch (IOException ignored) {}
            MediaFiles.delete(getContentResolver(), uri);
            getSharedPreferences("downloads", MODE_PRIVATE).edit().remove(COMPAT_PENDING).apply();
            output = null;
            uri = null;
        }
    }

    private static final class BoundedStream extends FilterInputStream {
        private long remaining;

        BoundedStream(InputStream stream, long length) {
            super(stream);
            remaining = length;
        }

        @Override public int read() throws IOException {
            if (remaining == 0) return -1;
            int value = super.read();
            if (value != -1) remaining--;
            return value;
        }

        @Override public int read(byte[] bytes, int offset, int length) throws IOException {
            if (length == 0) return 0;
            if (remaining == 0) return -1;
            int count = super.read(bytes, offset, (int) Math.min(remaining, length));
            if (count > 0) remaining -= count;
            return count;
        }

        @Override public int available() throws IOException {
            return (int) Math.min(remaining, super.available());
        }

        @Override public long skip(long count) throws IOException {
            long skipped = super.skip(Math.min(count, remaining));
            remaining -= skipped;
            return skipped;
        }
    }
}
