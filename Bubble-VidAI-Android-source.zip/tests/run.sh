#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
output="$(mktemp -d)"
trap 'rm -rf "$output"' EXIT
javac -d "$output" app/src/main/java/cz/bubble/vidai/ByteRange.java \
    app/src/main/java/cz/bubble/vidai/Motion.java tests/ProjectLogicTest.java
java -cp "$output" cz.bubble.vidai.ProjectLogicTest
