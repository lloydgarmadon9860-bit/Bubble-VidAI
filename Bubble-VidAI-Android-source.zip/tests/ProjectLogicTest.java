package cz.bubble.vidai;

public final class ProjectLogicTest {
    public static void main(String[] args) {
        same(ByteRange.parse("bytes=10-19", 100), new ByteRange(10, 19));
        same(ByteRange.parse("bytes=10-", 100), new ByteRange(10, 99));
        same(ByteRange.parse("bytes=-12", 100), new ByteRange(88, 99));
        same(ByteRange.parse("bytes=5-200", 100), new ByteRange(5, 99));
        same(ByteRange.parse("bytes=100-", 100), null);
        same(ByteRange.parse("bytes=-0", 100), null);
        same(ByteRange.parse("bytes=4-1", 100), null);
        same(ByteRange.parse("bytes=0-1,3-4", 100), null);
        Motion slide = new Motion(new int[]{0, 8}, "slide", 2, 2, 24);
        same(slide.at(0), new Motion.Pose(0, 0, 1, 1));
        same(slide.at(2), new Motion.Pose(0, 8, 0, 1));
        same(slide.at(2.425), new Motion.Pose(0, 8, .5f, 1));
        same(slide.at(3), new Motion.Pose(0, 8, 1, 1));
        same(slide.at(0), new Motion.Pose(0, 0, 1, 1));
        Motion fade = new Motion(new int[]{2, 4}, "fade", 2, 2, 24);
        same(fade.at(2), new Motion.Pose(2, 4, 1, 0));
        same(fade.at(2.175), new Motion.Pose(2, 4, 1, .5f));
        same(new Motion(new int[]{4}, "fade", 2, 2, -1).at(2), new Motion.Pose(4, 4, 1, 1));
        System.out.println("Byte-range handling and motion timing passed.");
    }

    private static void same(Object actual, Object expected) {
        if (!java.util.Objects.equals(actual, expected)) {
            throw new AssertionError("Expected " + expected + ", got " + actual);
        }
    }
}
