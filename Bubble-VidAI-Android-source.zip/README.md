# Bubble VidAI 0.6 Alpha

Android 10 nebo novější. Aplikace zpracovává video v zařízení a při běhu nepotřebuje síť.

## Sestavení

Projekt otevři v Android Studiu nebo z kořene spusť `./gradlew :app:assembleDebug` s JDK 17 a Android SDK 35. Při prvním sestavení Gradle stáhne knihovny. APK vznikne v `app/build/outputs/apk/debug/`.

Soubory `index.html`, `icon.png`, `MainActivity.java`, `AndroidManifest.xml` a `app.gradle` v kořeni jsou kompatibilní kopie pro stávající GitHub Actions. Vlastní projekt je v `app/`.

## Export

Turbo a Standard ukládají MP4 do Stažených souborů → Bubble VidAI. Turbo vybírá hardwarový dekodér a enkodér. Když je nelze použít, program zkusí Standard. Rozlišení a maximální FPS se řídí zdrojovým videem, dostupnými kodeky a teplotním stavem. Při převodu HDR na kompatibilní H.264 MP4 se použije SDR. Kompatibilní zvuk AAC se předává bez nového kódování, pokud to dovolí vstup a zvolený režim.

Compatibility zaznamenává video v reálném čase přes WebView. Podporované formáty určuje MediaRecorder v zařízení. Při tomto režimu nech aplikaci otevřenou. Dokončené soubory zůstávají ve Stažených souborech. Rozpracovaný projekt se obnoví, pokud je zdrojové video stále dostupné. Přerušený export lze z projektu spustit znovu.

## Ověření

`tests/run.sh` testuje práci s rozsahy videa, časování přesunů a prolínání. `./gradlew :app:lintDebug` ověří použití Android API. Hardwarový export, teplotní reakce, nativní přístup k médiím a oznámení ověř na fyzickém Androidu. Pro přímou aktualizaci existující instalace je potřeba stejný podpis aplikace.
