'use strict';

const $ = id => document.getElementById(id);
const bridge = window.VidAI;
const video = $('v');
const canvas = $('c');
const ctx = canvas.getContext('2d');
const sample = document.createElement('canvas');
sample.width = sample.height = 12;
const sampleCtx = sample.getContext('2d', {willReadFrequently: true});
const names = ['Bubble VidAI', 'Sora', 'AI Generated', 'AI Enhanced', 'Synthetic Media', 'AI Studio',
    'Made with AI', 'Custom', 'Flow AI'];
const keys = ['user', 'size', 'color', 'min', 'max', 'motion', 'opacity', 'font', 'weight', 'spacing',
    'quality', 'fps', 'format', 'engine', 'quickLength'];
const markKeys = new Set(['user', 'font', 'weight', 'spacing']);
const motionKeys = new Set(['min', 'max', 'motion']);
const defaultPositions = [0, 2, 6, 8];

let selected = 0;
let positions = [...defaultPositions];
let seed = Math.floor(Math.random() * 0x100000000) | 0;
let activeMotion, markCache = null, customLogo = null, loadingLogo = false;
let files = [], fileIndex = 0, objectURL = '', pendingSeek = 0;
let onlyFavorites = false;
let renderPending = 0, framePending = 0, frameIsVideoCallback = false;
let contrastColor = 'white', contrastTime = -1, contrastBox = null;
let nativeTimer = 0, nativeId = '', nativeStarted = 0, lastNative = '';
let busy = false, recording = null, cancelled = false;
let audioContext, audioSource, audioDestination, audioVolume;
let saveTimer = 0, lastSave = '', statusRestored = false;
const persistedResults = new Set();
const browserURLs = [];

function readLocal(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
}
function writeLocal(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch { return false; }
}
let favorites = readLocal('vidfav', []);
if (!Array.isArray(favorites)) favorites = [];
const presets = Object.assign(Object.create(null), readLocal('bubblePresets', {}));
function values() { return Object.fromEntries(keys.map(key => [key, $(key).value])); }
function message(text) { $('status').textContent = text; }
function tint(mode) { return mode === 'white' ? 1 : mode === 'black' ? 2 : 0; }

function image(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('Logo nelze načíst.'));
        img.src = url;
    });
}

function selectMark(index) {
    selected = index;
    $('customLabel').hidden = index !== 7;
    markCache = null;
    updateLibrary();
    requestDraw();
    queueSave();
}

function updateLibrary() {
    $('library').replaceChildren();
    names.forEach((name, index) => {
        if (onlyFavorites && !favorites.includes(index)) return;
        const cell = document.createElement('div');
        cell.className = 'tile' + (selected === index ? ' active' : '');
        const star = document.createElement('button');
        star.className = 'star';
        star.textContent = favorites.includes(index) ? '★' : '☆';
        star.setAttribute('aria-label', name + ' · oblíbené');
        star.onclick = () => {
            if (busy) return;
            favorites = favorites.includes(index) ? favorites.filter(i => i !== index) : [...favorites, index];
            writeLocal('vidfav', favorites);
            updateLibrary();
        };
        const button = document.createElement('button');
        button.style.cssText = 'background:none;border:0;width:100%;padding:4px';
        const src = index === 7 ? customLogo?.src : 'mark-' + index + '-white.png';
        if (src) {
            const thumb = document.createElement('img');
            thumb.alt = '';
            thumb.src = src;
            button.append(thumb);
        } else {
            const placeholder = document.createElement('div');
            placeholder.style.cssText = 'height:61px;display:grid;place-items:center';
            placeholder.textContent = '＋';
            button.append(placeholder);
        }
        button.append(name);
        button.setAttribute('aria-label', name);
        button.onclick = () => { if (!busy) selectMark(index); };
        cell.append(star, button);
        $('library').append(cell);
    });
}

function updatePositions() {
    $('positions').replaceChildren();
    for (let i = 0; i < 9; i++) {
        const button = document.createElement('button');
        const enabled = positions.includes(i);
        button.textContent = enabled ? '●' : '○';
        button.className = enabled ? 'active' : '';
        button.setAttribute('aria-label', 'Pozice ' + (i + 1));
        button.setAttribute('aria-pressed', String(enabled));
        button.onclick = () => {
            if (busy || enabled && positions.length === 1) return;
            positions = enabled ? positions.filter(position => position !== i) : [...positions, i];
            updatePositions();
            resetMotion();
            requestDraw();
            queueSave();
        };
        $('positions').append(button);
    }
}

function intervals() {
    const min = Math.max(1, Math.min(60, Number($('min').value) || 3));
    return [min, Math.max(min, Math.min(60, Number($('max').value) || 7))];
}
function smooth(value) {
    const t = Math.max(0, Math.min(1, value));
    return t * t * (3 - 2 * t);
}
class Motion {
    constructor(grid, mode, min, max, randomSeed) {
        Object.assign(this, {grid, mode, min, max, randomSeed});
        this.reset();
    }
    random() {
        this.state = (Math.imul(this.state, 1664525) + 1013904223) | 0;
        return (this.state >>> 0) / 4294967296;
    }
    reset() {
        this.state = this.randomSeed;
        this.before = this.after = 0;
        this.previous = this.current = 0;
        this.next = this.min + this.random() * (this.max - this.min);
    }
    at(seconds) {
        if (this.mode === 'static' || this.grid.length === 1) {
            return {before: this.grid[0], after: this.grid[0], mix: 1, alpha: 1};
        }
        if (seconds < this.current) this.reset();
        while (seconds >= this.next) {
            this.before = this.after;
            this.after = (this.before + 1 + Math.floor(this.random() * (this.grid.length - 1))) % this.grid.length;
            this.previous = this.current;
            this.current = this.next;
            this.next += this.min + this.random() * (this.max - this.min);
        }
        const since = seconds - this.current;
        return {
            before: this.grid[this.before], after: this.grid[this.after],
            mix: this.mode === 'slide' && this.current ? smooth(since / Math.min(.85, (this.current - this.previous) * .5)) : 1,
            alpha: this.mode === 'fade' ? Math.min(this.current === 0 ? 1 : smooth(since / .35),
                smooth((this.next - seconds) / .35)) : 1
        };
    }
}
function resetMotion() {
    activeMotion = new Motion(positions, $('motion').value, ...intervals(), seed);
    contrastTime = -1;
}

const loadedLogos = new Map();
function loadLogoVariants(index) {
    if (index === 7) return Promise.resolve([customLogo, customLogo]);
    if (!loadedLogos.has(index)) {
        const prefix = 'mark-' + index + '-';
        loadedLogos.set(index, Promise.all([image(prefix + 'white.png'), image(prefix + 'black.png')]));
    }
    return loadedLogos.get(index);
}

function spacingText(target, value, x, y, spacing) {
    if ('letterSpacing' in target) {
        target.letterSpacing = spacing + 'px';
        if (y !== undefined) target.fillText(value, x, y);
        return target.measureText(value).width;
    }
    let total = 0;
    for (const character of value) {
        if (y !== undefined) target.fillText(character, x + total, y);
        total += target.measureText(character).width + spacing;
    }
    return total;
}

function composeMark(index, logo, color, options) {
    const target = document.createElement('canvas');
    const context = target.getContext('2d');
    const unit = 128;
    const fullText = (options.user || '').trim().slice(0, 140);
    const label = index === 8 ? '' : index === 7 ? (fullText || names[7]) : names[index];
    const tag = index === 7 || index === 8 || !fullText ? '' : fullText.startsWith('@') ? fullText : '@' + fullText;
    const fonts = {'system-ui':'system-ui', Arial:'Arial', Georgia:'Georgia', Verdana:'Verdana',
        'Courier New':'"Courier New"'};
    const font = options.weight + ' 92px ' + (fonts[options.font] || 'system-ui');
    const spacing = (Number(options.spacing) || 0) * 1.8;
    context.font = font;
    const measured = spacingText(context, label, 0, undefined, spacing);
    context.font = '55px system-ui';
    const subtitleWidth = spacingText(context, tag, 0, undefined, spacing);
    const naturalWidth = Math.ceil(168 + Math.max(measured, subtitleWidth));
    target.width = index === 8 ? 128 : Math.min(4096, naturalWidth);
    target.height = index === 8 ? 128 : tag ? 157 : 135;
    if (logo) {
        const ratio = unit / Math.max(logo.naturalWidth, logo.naturalHeight);
        const w = logo.naturalWidth * ratio;
        const h = logo.naturalHeight * ratio;
        context.drawImage(logo, (unit - w) / 2, (unit - h) / 2, w, h);
    }
    if (label) {
        context.fillStyle = color;
        context.translate(160, 0);
        if (naturalWidth > 4096) context.scale((4096 - 168) / (naturalWidth - 168), 1);
        context.font = font;
        spacingText(context, label, 0, tag ? 90 : 101, spacing);
        if (tag) {
            context.font = '55px system-ui';
            spacingText(context, tag, 0, 147, spacing);
        }
    }
    return target;
}

function marks() {
    if (markCache) return markCache;
    const index = selected, options = values();
    const pending = {ready: null};
    markCache = pending;
    pending.promise = loadLogoVariants(index).then(([white, black]) => {
        pending.ready = {white: composeMark(index, white, 'white', options),
            black: composeMark(index, black, 'black', options)};
        if (markCache === pending) requestDraw();
        return pending.ready;
    }).catch(error => {
        pending.error = error;
        if (markCache === pending) message(error.message);
        return null;
    });
    return pending;
}
function coordinate(grid, size, span, margin) {
    return margin + grid * (size - span - 2 * margin) / 2;
}
function watermarkBox(mark, time) {
    const {width, height} = canvas;
    const side = Math.min(width, height);
    const margin = side * .035;
    const scale = Math.min(side * .055 * Number($('size').value) / 12800, (width - 2 * margin) / mark.width);
    const w = mark.width * scale, h = mark.height * scale;
    const pose = activeMotion.at(time);
    const x0 = coordinate(pose.before % 3, width, w, margin);
    const y0 = coordinate(Math.floor(pose.before / 3), height, h, margin);
    return {x: x0 + (coordinate(pose.after % 3, width, w, margin) - x0) * pose.mix,
        y: y0 + (coordinate(Math.floor(pose.after / 3), height, h, margin) - y0) * pose.mix,
        w, h, alpha: pose.alpha};
}

function chooseContrast(box, time) {
    if ($('color').value !== 'auto') return $('color').value;
    if (time >= contrastTime && time - contrastTime < .14 && contrastBox
            && Math.abs(box.x - contrastBox.x) < box.w * .2 && Math.abs(box.y - contrastBox.y) < box.h * .2) {
        return contrastColor;
    }
    sampleCtx.drawImage(canvas, box.x, box.y, box.w, box.h, 0, 0, 12, 12);
    const data = sampleCtx.getImageData(0, 0, 12, 12).data;
    let total = 0;
    for (let y = 2; y < 12; y += 4) for (let x = 2; x < 12; x += 4) {
        const i = 4 * (y * 12 + x);
        total += .2126 * data[i] + .7152 * data[i + 1] + .0722 * data[i + 2];
    }
    const brightness = total / (9 * 255);
    if (contrastTime < 0 || Math.abs(brightness - .45) > .035) contrastColor = brightness > .45 ? 'black' : 'white';
    contrastTime = time;
    contrastBox = box;
    return contrastColor;
}

function draw(time = video.currentTime || 0) {
    const {width, height} = canvas;
    if (video.readyState < 2) {
        ctx.fillStyle = '#202025';
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#aaa';
        ctx.font = '20px system-ui';
        ctx.textAlign = 'center';
        ctx.fillText('Importuj video', width / 2, height / 2);
        ctx.textAlign = 'left';
        return;
    }
    ctx.drawImage(video, 0, 0, width, height);
    const pair = marks().ready;
    if (pair) {
        const box = watermarkBox(pair.white, time);
        let color;
        try { color = chooseContrast(box, time); }
        catch { color = 'white'; }
        ctx.globalAlpha = Number($('opacity').value) / 100 * box.alpha;
        ctx.drawImage(pair[color], box.x, box.y, box.w, box.h);
        ctx.globalAlpha = 1;
    }
    const fraction = busy ? 0 : Number($('compare').value) / 100;
    if (fraction) {
        const cut = Math.round(width * fraction);
        ctx.drawImage(video, 0, 0, video.videoWidth * fraction, video.videoHeight, 0, 0, cut, height);
        if (cut < width) {
            ctx.fillStyle = 'white';
            ctx.fillRect(cut, 0, Math.max(1, width / 500), height);
        }
    }
    if (recording?.track) {
        if (recording.frameRequest) recording.track.requestFrame();
        recording.frames++;
    }
}

function requestDraw() {
    if (renderPending || recording) return;
    renderPending = requestAnimationFrame(() => {
        renderPending = 0;
        draw();
    });
}
function watchFrames() {
    if (framePending || video.paused || document.hidden && !recording) return;
    const frame = (now, metadata) => {
        framePending = 0;
        const time = metadata?.mediaTime ?? video.currentTime;
        const active = recording;
        if (!active || time >= active.nextFrame - .002) {
            draw(time);
            if (active) active.nextFrame = time + 1 / active.fps;
        }
        if (active && time >= active.end) stopRecorder(active);
        watchFrames();
    };
    frameIsVideoCallback = typeof video.requestVideoFrameCallback === 'function';
    framePending = frameIsVideoCallback ? video.requestVideoFrameCallback(frame) : requestAnimationFrame(frame);
}
function stopWatchingFrames() {
    if (!framePending) return;
    if (frameIsVideoCallback) video.cancelVideoFrameCallback(framePending);
    else cancelAnimationFrame(framePending);
    framePending = 0;
}
function sizeCanvas(encoding) {
    if (!video.videoWidth) return;
    const dimension = video.videoWidth >= video.videoHeight ? video.videoWidth : video.videoHeight;
    const limit = encoding ? 3840 : Math.min(1080, Math.max(360, Math.ceil(canvas.clientWidth * Math.min(2, devicePixelRatio))));
    const scale = Math.min(1, limit / dimension);
    canvas.width = Math.max(2, Math.round(video.videoWidth * scale / 2) * 2);
    canvas.height = Math.max(2, Math.round(video.videoHeight * scale / 2) * 2);
}

function fillQueue() {
    $('queue').replaceChildren();
    files.forEach((item, i) => {
        const option = document.createElement('option');
        option.value = String(i);
        option.textContent = item.name + (item.retained === false ? ' · dočasný přístup' : '');
        $('queue').append(option);
    });
    $('queue').value = String(fileIndex);
    $('queueLabel').hidden = files.length < 2;
}
function openFile(index, seek = 0) {
    if (!files[index]) return;
    fileIndex = index;
    $('queue').value = String(index);
    pendingSeek = seek;
    video.pause();
    if (objectURL) URL.revokeObjectURL(objectURL);
    objectURL = files[index].file ? URL.createObjectURL(files[index].file) : '';
    video.src = objectURL || files[index].url;
    video.load();
    resetMotion();
    message('Načítám ' + files[index].name + '…');
    queueSave();
}
function importFiles(next) {
    if (busy || !next.length) return;
    files = next;
    fileIndex = 0;
    seed = Math.floor(Math.random() * 0x100000000) | 0;
    fillQueue();
    openFile(0);
    saveProject();
}

document.addEventListener('input', event => {
    if (markKeys.has(event.target.id)) markCache = null;
    if (motionKeys.has(event.target.id)) resetMotion();
    if (['size','color'].includes(event.target.id)) contrastTime = -1;
    $('sz').textContent = $('size').value + ' %';
    requestDraw();
    queueSave();
});
$('file').onchange = event => {
    if (bridge) return;
    importFiles(Array.from(event.target.files, file => ({name: file.name, file})));
};
$('queue').onchange = () => { if (!busy) openFile(Number($('queue').value)); };
$('play').onclick = () => {
    if (!video.src || busy) return;
    if (video.paused) video.play().catch(e => message(e.message));
    else video.pause();
};
$('seek').oninput = () => {
    if (!busy && Number.isFinite(video.duration)) video.currentTime = Number($('seek').value) / 1000 * video.duration;
};
video.onloadedmetadata = () => {
    sizeCanvas(Boolean(recording));
    if (pendingSeek > 0 && Number.isFinite(video.duration)) video.currentTime = Math.min(video.duration, pendingSeek);
    pendingSeek = 0;
    message(statusRestored ? 'Rozpracovaný projekt obnoven.' : 'Video připraveno.');
    statusRestored = false;
    requestDraw();
};
video.onloadeddata = requestDraw;
video.onseeked = () => { contrastTime = -1; requestDraw(); };
video.ontimeupdate = () => {
    const seconds = Math.floor(video.currentTime);
    $('time').textContent = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
    $('seek').value = video.duration ? video.currentTime / video.duration * 1000 : 0;
    if (recording && video.currentTime >= recording.end) stopRecorder(recording);
    if (!busy) queueSave();
};
video.onplay = () => { $('play').textContent = 'Ⅱ Pauza'; watchFrames(); };
video.onpause = () => {
    $('play').textContent = '▶ Přehrát';
    stopWatchingFrames();
    if (!busy) queueSave();
};
video.onended = () => { if (recording) stopRecorder(recording); };
video.onerror = () => message('Náhled videa nelze přehrát. Zkus jiný soubor nebo nativní export.');
window.addEventListener('resize', () => {
    if (!recording) { sizeCanvas(false); requestDraw(); }
});
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) { requestDraw(); watchFrames(); if (bridge) refreshNative(); }
});

$('logo').onchange = async () => {
    const file = $('logo').files[0];
    if (!file || loadingLogo) return;
    if (file.size > 24 * 1024 * 1024) { message('Logo musí mít méně než 24 MB.'); return; }
    const url = URL.createObjectURL(file);
    loadingLogo = true;
    try {
        const original = await image(url);
        const ratio = Math.min(1, 1024 / Math.max(original.naturalWidth, original.naturalHeight));
        const logo = document.createElement('canvas');
        logo.width = Math.max(1, Math.round(original.naturalWidth * ratio));
        logo.height = Math.max(1, Math.round(original.naturalHeight * ratio));
        logo.getContext('2d').drawImage(original, 0, 0, logo.width, logo.height);
        const png = logo.toDataURL('image/png');
        const stored = bridge ? bridge.saveLogo(png.split(',')[1]) : writeLocal('vidaiLogo06', png);
        if (!stored) throw new Error('Logo nelze uložit do zařízení.');
        customLogo = await image(png);
        markCache = null;
        updateLibrary();
        requestDraw();
        message('Vlastní logo uloženo.');
    } catch (error) { message(error.message); }
    finally { loadingLogo = false; URL.revokeObjectURL(url); $('logo').value = ''; }
};

function savedSettings() { return {selected, positions, values: values(), seed}; }
function applySettings(state) {
    if (Number.isInteger(state.selected) && state.selected >= 0 && state.selected < names.length) selected = state.selected;
    const grid = Array.isArray(state.positions) ? state.positions.filter(n => Number.isInteger(n) && n >= 0 && n < 9) : [];
    positions = grid.length ? Array.from(new Set(grid)) : [...defaultPositions];
    if (Number.isInteger(state.seed)) seed = state.seed | 0;
    for (const key of keys) {
        if (state.values?.[key] == null) continue;
        const field = $(key), value = state.values[key];
        if (field.tagName !== 'SELECT' || [...field.options].some(option => option.value === value)) field.value = value;
    }
    $('customLabel').hidden = selected !== 7;
    $('sz').textContent = $('size').value + ' %';
    markCache = null;
    resetMotion();
    updateLibrary();
    updatePositions();
    requestDraw();
}
function saveProject() {
    clearTimeout(saveTimer);
    saveTimer = 0;
    const draft = {...savedSettings(), media: files.map(file => file.uri || ''),
        index: fileIndex, seek: Math.floor(video.currentTime || pendingSeek || 0)};
    const json = JSON.stringify(draft);
    if (json === lastSave) return;
    if (bridge ? bridge.save(json) : writeLocal('vidaiDraft06', draft)) lastSave = json;
}
function queueSave() {
    if (saveTimer) return;
    saveTimer = setTimeout(() => { saveTimer = 0; saveProject(); }, 450);
}

function setBusy(active) {
    busy = active;
    for (const id of ['export','quick','batch','play','applyPreset','savePreset','deletePreset','fav']) $(id).disabled = active;
    document.querySelectorAll('input,select').forEach(element => { element.disabled = active; });
    $('cancel').hidden = !active;
}
function addResult(result) {
    if (persistedResults.has(result.uri)) return;
    persistedResults.add(result.uri);
    const button = document.createElement(bridge ? 'button' : 'a');
    button.textContent = result.name + ' · ' + (bridge ? 'otevřít' : 'stáhnout');
    button.style.display = 'block';
    if (bridge) button.onclick = () => bridge.open(result.uri);
    else { button.href = result.uri; button.download = result.name; }
    $('results').append(button);
}

function refreshNative() {
    if (!bridge) return;
    let state;
    try { state = JSON.parse(bridge.status()); }
    catch { return; }
    if (!state.id) return;
    if (nativeId && state.id !== nativeId && performance.now() - nativeStarted < 6000) return;
    if (nativeId && state.id !== nativeId) {
        nativeId = '';
        setBusy(false);
        message('Nativní export se nepodařilo spustit.');
        return;
    }
    if (state.id === lastNative && state.phase !== 'active') return;
    if (state.phase === 'active') {
        if (!busy) setBusy(true);
        nativeId = state.id;
    } else {
        lastNative = state.id;
        nativeId = '';
        setBusy(false);
    }
    $('progress').value = state.progress || 0;
    $('perf').textContent = state.performance || '—';
    message(state.message);
    (state.outputs || []).forEach(addResult);
}
function watchNative() {
    if (nativeTimer) return;
    refreshNative();
    nativeTimer = setInterval(() => {
        if (!document.hidden && (nativeId || busy)) refreshNative();
    }, 650);
}

function waitForLoaded() {
    return new Promise((resolve, reject) => {
        if (video.readyState >= 2) { resolve(); return; }
        const timeout = setTimeout(() => done(new Error('Na načtení videa se čekalo příliš dlouho.')), 15000);
        const onLoaded = () => done();
        const onError = () => done(new Error('Video nelze otevřít.'));
        function done(error) {
            clearTimeout(timeout);
            video.removeEventListener('loadeddata', onLoaded);
            video.removeEventListener('error', onError);
            error ? reject(error) : resolve();
        }
        video.addEventListener('loadeddata', onLoaded);
        video.addEventListener('error', onError);
    });
}

function recordingMime(format) {
    const supported = format === 'MP4'
        ? ['video/mp4;codecs=avc1.42001f,mp4a.40.2', 'video/mp4']
        : ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9,opus', 'video/webm'];
    return supported.find(mime => MediaRecorder.isTypeSupported(mime));
}
async function setupAudio() {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    if (!audioSource) {
        audioSource = audioContext.createMediaElementSource(video);
        audioVolume = audioContext.createGain();
        audioDestination = audioContext.createMediaStreamDestination();
        audioSource.connect(audioVolume);
        audioVolume.connect(audioContext.destination);
        audioSource.connect(audioDestination);
    }
    await audioContext.resume();
    audioVolume.gain.value = 0;
}
function stopRecorder(active) {
    if (active.recorder.state === 'recording') {
        video.pause();
        active.recorder.stop();
    }
}
function writeChunk(bytes) {
    for (let i = 0; i < bytes.length; i += 192 * 1024) {
        const block = bytes.subarray(i, i + 192 * 1024);
        let binary = '';
        for (let j = 0; j < block.length; j += 8192) {
            binary += String.fromCharCode(...block.subarray(j, j + 8192));
        }
        if (!bridge.chunkCompat(btoa(binary))) throw new Error('Video nelze zapsat do úložiště.');
    }
}

async function record(item, limit, mime, format, batchIndex, count) {
    await waitForLoaded();
    if (!Number.isFinite(video.duration) || !(video.duration > 0)) throw new Error('Video nemá platnou délku.');
    if (cancelled) return;
    video.pause();
    if (video.currentTime > 0.005) {
        video.currentTime = 0;
        if (video.seeking) await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => { video.removeEventListener('seeked', done); reject(new Error('Náhled se nepřetočil.')); }, 5000);
            function done() { clearTimeout(timeout); resolve(); }
            video.addEventListener('seeked', done, {once: true});
        });
    }
    if (cancelled) return;
    sizeCanvas(true);
    resetMotion();
    const fps = Math.min(60, Number($('fps').value) || 60);
    const end = Math.min(video.duration, limit || video.duration);
    const capture = canvas.captureStream(fps);
    const track = capture.getVideoTracks()[0];
    audioDestination.stream.getAudioTracks().forEach(audioTrack => capture.addTrack(audioTrack));
    if (!track) throw new Error('Záznam videa není na tomto zařízení dostupný.');
    const ext = format === 'MP4' ? 'mp4' : 'webm';
    const base = item.name.replace(/\.[^.]+$/, '').slice(0, 80);
    const name = base + (limit ? '-Bubble-Preview.' : '-Bubble-VidAI.') + ext;
    const simpleMime = 'video/' + ext;
    const chunks = [];
    let io = Promise.resolve(), writeFailure = null;
    try {
        const factor = {auto: 5, max: 10, balanced: 4, small: 1.5}[$('quality').value];
        const recorder = new MediaRecorder(capture, {mimeType: mime,
            videoBitsPerSecond: Math.min(85_000_000, Math.max(400_000, canvas.width * canvas.height * factor * fps / 60))});
        if (bridge && !bridge.beginCompat(name, simpleMime)) throw new Error('Výstup nelze otevřít.');
        const active = {recorder, track, fps, end, frames: 0, nextFrame: 0, frameRequest: false};
        recording = active;
        const started = performance.now();
        message(item.name + ' · ' + (batchIndex + 1) + '/' + count + ' · nech aplikaci otevřenou.');
        const ticker = setInterval(() => {
            const elapsed = Math.max(.01, (performance.now() - started) / 1000);
            const time = Math.min(end, video.currentTime);
            const rate = time / elapsed;
            $('progress').value = 100 * (batchIndex + time / end) / count;
            $('perf').textContent = rate.toFixed(2) + '× · ' + (active.frames / elapsed).toFixed(1)
                + ' sn./s vykresleno' + (rate > .001 ? ' · zbývá přibližně ' + Math.ceil((end - time) / rate) + ' s' : '');
            if (time >= end) stopRecorder(active);
        }, 350);
        try {
            await new Promise((resolve, reject) => {
                recorder.ondataavailable = event => {
                    if (!event.data.size || cancelled) return;
                    if (!bridge) { chunks.push(event.data); return; }
                    io = io.then(async () => {
                        if (cancelled || writeFailure) return;
                        writeChunk(new Uint8Array(await event.data.arrayBuffer()));
                    }).catch(error => { writeFailure = error; stopRecorder(active); });
                };
                recorder.onstop = resolve;
                recorder.onerror = event => reject(event.error || new Error('Kódování selhalo.'));
                draw(0);
                recorder.start(500);
                video.play().catch(reject);
            });
            await io;
            if (writeFailure) throw writeFailure;
            if (cancelled) return;
            if (bridge) {
                const uri = bridge.endCompat();
                if (!uri) throw new Error('Video nelze uložit.');
                addResult({name, uri});
            } else {
                const uri = URL.createObjectURL(new Blob(chunks, {type: simpleMime}));
                browserURLs.push(uri);
                addResult({name, uri});
            }
        } finally {
            clearInterval(ticker);
            if (recorder.state === 'recording') stopRecorder(active);
        }
    } finally {
        track.stop();
        recording = null;
        if (bridge) bridge.abortCompat();
    }
}

async function beginExport(mode) {
    if (busy || loadingLogo) return;
    if (!files.length) { message('Nejdříve importuj video.'); return; }
    if (selected === 7 && !customLogo) { message('Importuj vlastní logo.'); return; }
    if (selected >= 1 && selected <= 6 || selected === 8) {
        const label = selected === 1 || selected === 8 ? names[selected] : 'vybrané logo';
        if (!confirm('Potvrď, že ' + label + ' odpovídá původu nebo úpravě videa.')) return;
    }
    const limit = mode === 'quick' ? Number($('quickLength').value) : 0;
    const targets = mode === 'batch' ? files : [files[fileIndex]];
    const previous = fileIndex, format = $('format').value, engine = $('engine').value;
    const hasNative = bridge && format === 'MP4' && engine !== 'compat';
    cancelled = false;
    saveProject();
    setBusy(true);
    $('progress').value = 0;
    $('perf').textContent = '—';
    message('Připravuji export…');
    try {
        if (!hasNative) {
            if (!window.MediaRecorder || !canvas.captureStream) throw new Error('Režim Compatibility není dostupný.');
            await setupAudio();
        }
        const pair = await marks().promise;
        if (!pair) throw new Error('Vodoznak nelze připravit.');
        if (cancelled) throw new Error('Export zrušen.');
        if (hasNative) {
            const [min, max] = intervals();
            nativeId = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
            nativeStarted = performance.now();
            video.pause();
            bridge.export(JSON.stringify({id: nativeId, media: targets.map(({uri, name}) => ({uri, name})),
                light: pair.white.toDataURL().split(',')[1], dark: pair.black.toDataURL().split(',')[1],
                positions, seed, motion: $('motion').value, min, max, fps: Number($('fps').value) || 0,
                color: tint($('color').value), scale: Number($('size').value) / 100,
                opacity: Number($('opacity').value) / 100, quality: $('quality').value,
                limit: limit * 1000, turbo: engine === 'turbo'}));
            return;
        }
        const mime = recordingMime(format);
        if (!mime) throw new Error('Formát není v režimu Compatibility dostupný. Zvol jiný formát nebo nativní MP4.');
        const failures = [];
        let saved = 0;
        for (let i = 0; i < targets.length && !cancelled; i++) {
            try {
                if (mode === 'batch' && fileIndex !== i) openFile(i);
                await record(targets[i], limit, mime, format, i, targets.length);
                if (!cancelled) saved++;
            } catch (error) { failures.push(targets[i].name + ': ' + error.message); }
        }
        if (mode === 'batch' && fileIndex !== previous) openFile(previous);
        if (!cancelled) {
            $('progress').value = saved > 0 ? 100 : 0;
            message('Uloženo videí: ' + saved + '.' + (failures.length ? ' ' + failures.join(' · ') : ''));
        }
    } catch (error) {
        message(error.message);
    } finally {
        if (!nativeId) {
            setBusy(false);
            if (audioVolume) audioVolume.gain.value = 1;
            video.pause();
            sizeCanvas(false);
            requestDraw();
        }
    }
}

$('fav').onclick = () => {
    onlyFavorites = !onlyFavorites;
    $('fav').classList.toggle('active', onlyFavorites);
    updateLibrary();
};
$('export').onclick = () => beginExport('single');
$('quick').onclick = () => beginExport('quick');
$('batch').onclick = () => beginExport('batch');
$('cancel').onclick = () => {
    cancelled = true;
    if (nativeId) bridge.cancel();
    if (recording) stopRecorder(recording);
    message('Export zrušen.');
};
$('format').onchange = () => {
    if ($('format').value === 'WebM') $('engine').value = 'compat';
    queueSave();
};
$('engine').onchange = () => {
    if ($('engine').value !== 'compat') $('format').value = 'MP4';
    queueSave();
};

function presetOptions(current) {
    $('presets').replaceChildren();
    for (const key of Object.keys(presets)) {
        const option = document.createElement('option');
        option.textContent = key;
        $('presets').append(option);
    }
    if (current) $('presets').value = current;
}
$('savePreset').onclick = () => {
    const name = prompt('Název předvolby')?.trim().slice(0, 80);
    if (!name) return;
    presets[name] = savedSettings();
    if (!writeLocal('bubblePresets', presets)) message('Předvolbu nelze uložit.');
    presetOptions(name);
};
$('applyPreset').onclick = () => {
    const state = presets[$('presets').value];
    if (state) { applySettings(state); saveProject(); }
};
$('deletePreset').onclick = () => {
    delete presets[$('presets').value];
    writeLocal('bubblePresets', presets);
    presetOptions();
};

let installEvent;
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installEvent = event; });
$('install').onclick = async () => {
    if (installEvent) { await installEvent.prompt(); installEvent = null; }
    else $('installInfo').textContent = 'Pokud to prohlížeč nabízí, otevři jeho menu a zvol Přidat na plochu.';
};

window.Studio = {
    importNative: importFiles,
    onBackground() {
        saveProject();
        if (!nativeId && recording) {
            cancelled = true;
            stopRecorder(recording);
            message('Compatibility export byl přerušen při odchodu z aplikace.');
        }
        if (!nativeId && !recording) video.pause();
    }
};

async function start() {
    $('installPanel').hidden = Boolean(bridge);
    if (!bridge) {
        $('engine').value = 'compat';
        $('engine').querySelector('[value="standard"]').disabled = true;
        $('engine').querySelector('[value="turbo"]').disabled = true;
    }
    $('user').maxLength = 140;
    let saved;
    try { saved = bridge ? JSON.parse(bridge.restore()) : readLocal('vidaiDraft06', {}); }
    catch { saved = {}; }
    applySettings(saved);
    if (!bridge) $('engine').value = 'compat';
    const logo = saved.logo || readLocal('vidaiLogo06', '');
    if (logo) {
        image(logo).then(img => {
            customLogo = img;
            if (selected === 7) markCache = null;
            updateLibrary();
            requestDraw();
        }).catch(() => message('Uložené logo nelze obnovit.'));
    }
    if (saved.files?.length) {
        files = saved.files;
        const oldIndex = files.findIndex(item => item.index === saved.index);
        statusRestored = true;
        fillQueue();
        openFile(Math.max(0, oldIndex), oldIndex < 0 ? 0 : saved.seek || 0);
    } else if (saved.media?.some(Boolean)) {
        message('Nastavení obnoveno. Přístup k původnímu videu vypršel, vyber ho znovu.');
    }
    presetOptions();
    watchNative();
    requestAnimationFrame(() => {
        $('splash').style.opacity = '0';
        setTimeout(() => $('splash')?.remove(), 180);
    });
}
window.addEventListener('pagehide', () => {
    saveProject();
    for (const url of browserURLs) URL.revokeObjectURL(url);
});
start();
