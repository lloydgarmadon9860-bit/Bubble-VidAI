package cz.bubble.vidai;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import android.media.MediaCodec.BufferInfo;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.Metadata;
import androidx.media3.muxer.MuxerException;
import androidx.media3.transformer.DefaultMuxer;
import androidx.media3.transformer.Muxer;
import com.google.common.collect.ImmutableList;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Tracks actual MP4 video samples after they reach the muxer. */
@OptIn(markerClass = UnstableApi.class)
final class StandardMuxer implements Muxer {
    static final class Metrics {
        final AtomicLong latestUs = new AtomicLong();
        final AtomicInteger frames = new AtomicInteger();
    }

    static Factory factory(Metrics metrics) {
        DefaultMuxer.Factory output = new DefaultMuxer.Factory();
        return new Factory() {
            @Override public Muxer create(String path) throws MuxerException {
                return new StandardMuxer(output.create(path), metrics);
            }

            @Override public ImmutableList<String> getSupportedSampleMimeTypes(@C.TrackType int type) {
                return output.getSupportedSampleMimeTypes(type);
            }
        };
    }

    private final Muxer muxer;
    private final Metrics metrics;
    private final Set<Integer> video = new HashSet<>();

    private StandardMuxer(Muxer muxer, Metrics metrics) {
        this.muxer = muxer;
        this.metrics = metrics;
    }

    @Override public int addTrack(Format format) throws MuxerException {
        int track = muxer.addTrack(format);
        if (format.sampleMimeType != null && format.sampleMimeType.startsWith("video/")) video.add(track);
        return track;
    }

    @Override public void writeSampleData(int track, ByteBuffer buffer, BufferInfo info) throws MuxerException {
        int size = info.size;
        long time = info.presentationTimeUs;
        muxer.writeSampleData(track, buffer, info);
        if (size > 0 && video.contains(track)) {
            metrics.frames.incrementAndGet();
            metrics.latestUs.accumulateAndGet(time, Math::max);
        }
    }

    @Override public void addMetadataEntry(Metadata.Entry entry) { muxer.addMetadataEntry(entry); }
    @Override public void close() throws MuxerException { muxer.close(); }
}
