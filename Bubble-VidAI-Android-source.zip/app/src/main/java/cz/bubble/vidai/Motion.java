package cz.bubble.vidai;

final class Motion {
    private final int[] positions;
    private final String mode;
    private final double minimum;
    private final double maximum;
    private final int seed;

    Motion(int[] positions, String mode, double minimum, double maximum, int seed) {
        this.positions = positions;
        this.mode = mode;
        this.minimum = minimum;
        this.maximum = maximum;
        this.seed = seed;
    }

    record Pose(int before, int after, float mix, float alpha) {}

    private int state, before, after;
    private double previousTime, currentTime, nextTime;

    private double random() {
        state = state * 1664525 + 1013904223;
        return Integer.toUnsignedLong(state) / 4294967296.0;
    }

    private static float ease(double position) {
        float t = (float) Math.max(0, Math.min(1, position));
        return t * t * (3 - 2 * t);
    }

    Pose at(double seconds) {
        if (mode.equals("static") || positions.length == 1) return new Pose(positions[0], positions[0], 1, 1);
        if (nextTime == 0 || seconds < currentTime) {
            state = seed;
            before = after = 0;
            previousTime = currentTime = 0;
            nextTime = minimum + random() * (maximum - minimum);
        }
        while (seconds >= nextTime) {
            before = after;
            after = (before + 1 + (int) (random() * (positions.length - 1))) % positions.length;
            previousTime = currentTime;
            currentTime = nextTime;
            nextTime += minimum + random() * (maximum - minimum);
        }
        double since = seconds - currentTime;
        float mix = mode.equals("slide") ? ease(since / Math.min(.85, (currentTime - previousTime) * .5)) : 1;
        if (currentTime == 0) mix = 1;
        float alpha = mode.equals("fade") ? Math.min(currentTime == 0 ? 1 : ease(since / .35),
                ease((nextTime - seconds) / .35)) : 1;
        return new Pose(positions[before], positions[after], mix, alpha);
    }
}
