package cz.bubble.vidai;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.AtomicFile;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;

final class ProjectStore {
    private final AtomicFile draft;
    private final AtomicFile logo;

    ProjectStore(Context context) {
        draft = new AtomicFile(new File(context.getFilesDir(), "project.json"));
        logo = new AtomicFile(new File(context.getFilesDir(), "logo.png"));
    }

    synchronized void save(String project) throws IOException, JSONException {
        if (project.length() > 262144) throw new IOException("Projekt je příliš velký.");
        new JSONObject(project);
        write(draft, project.getBytes(StandardCharsets.UTF_8));
    }

    synchronized JSONObject load() {
        try {
            return new JSONObject(new String(draft.readFully(), StandardCharsets.UTF_8));
        } catch (IOException | JSONException e) {
            return new JSONObject();
        }
    }

    synchronized void saveLogo(String encoded) throws IOException {
        if (encoded.length() > 8_000_000) throw new IOException("Logo je příliš velké.");
        byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        if (!"image/png".equals(bounds.outMimeType) || bounds.outWidth < 1 || bounds.outHeight < 1
                || Math.max(bounds.outWidth, bounds.outHeight) > 1024) {
            throw new IOException("Logo musí být PNG s rozměry do 1024 × 1024.");
        }
        write(logo, bytes);
    }

    synchronized String logoData() {
        try {
            return "data:image/png;base64," + Base64.encodeToString(logo.readFully(), Base64.NO_WRAP);
        } catch (IOException e) {
            return "";
        }
    }

    private static void write(AtomicFile file, byte[] content) throws IOException {
        FileOutputStream out = file.startWrite();
        try {
            out.write(content);
            file.finishWrite(out);
        } catch (IOException e) {
            file.failWrite(out);
            throw e;
        }
    }
}
