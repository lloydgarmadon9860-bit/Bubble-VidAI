package cz.bubble.vidai;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.Clock;
import androidx.media3.effect.FrameDropEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.DefaultAssetLoaderFactory;
import androidx.media3.transformer.DefaultDecoderFactory;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;
import com.google.common.collect.ImmutableList;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@OptIn(markerClass = UnstableApi.class)
public final class ExportService extends Service {
    private static final String CHANNEL = "video-exports";
    private static final String CANCEL = "cz.bubble.vidai.CANCEL_EXPORT";
    private static final int NOTIFICATION = 71;
    private static final int RESULT_NOTIFICATION = 72;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile String snapshot = "{}";
    private static Job waiting;
    private static ExportService current;

    private final ArrayList<String> errors = new ArrayList<>();
    private final JSONArray outputs = new JSONArray();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final ProgressHolder progressHolder = new ProgressHolder();
    private final Runnable monitor = this::showProgress;
    private volatile Job job;
    private File output;
    private Transformer transformer;
    private StandardMuxer.Metrics metrics;
    private Media source;
    private AdaptiveCodec.Video metadata;
    private AdaptiveCodec.Plan plan;
    private Bitmap light, dark;
    private int index, thermalAtStart;
    private boolean thermalRestarted;
    private static final String PENDING_DOWNLOAD = "pendingDownload";
    private long started, duration;
    private boolean forceStandard;
    private String detail = "";

    static void prepare(Context context, String data) throws Exception {
        if (waiting != null || current != null && current.job != null) {
            throw new IllegalStateException("Jiný export stále běží.");
        }
        if (data.length() > 9_000_000) throw new IOException("Nastavení exportu je příliš velké.");
        Job next = new Job(new JSONObject(data));
        waiting = next;
        snapshot = state(next.id, "active", "Připravuji export…", 0, "", new JSONArray()).toString();
        try {
            context.startForegroundService(new Intent(context, ExportService.class));
        } catch (RuntimeException e) {
            waiting = null;
            throw e;
        }
    }

    static void rejected(String data, Exception e) {
        String id = "";
        try { id = new JSONObject(data).optString("id"); }
        catch (JSONException ignored) {}
        if (waiting == null && (current == null || current.job == null)) {
            snapshot = state(id, "error", readable(e), 0, "", new JSONArray()).toString();
        }
    }

    static String snapshot(Context context) {
        if ("{}".equals(snapshot)) return context.getSharedPreferences(CHANNEL, MODE_PRIVATE)
                .getString("status", "{}");
        return snapshot;
    }

    static void requestCancel() {
        MAIN.post(() -> { if (current != null) current.cancelExport(); });
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && CANCEL.equals(intent.getAction())) {
            cancelExport();
            return START_NOT_STICKY;
        }
        if (job != null) return START_NOT_STICKY;
        job = waiting;
        waiting = null;
        if (job == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        current = this;
        NotificationManager notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(CHANNEL, "Export videí",
                NotificationManager.IMPORTANCE_LOW));
        notifications.cancel(RESULT_NOTIFICATION);
        int type = Build.VERSION.SDK_INT >= 35 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
                : ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC;
        startForeground(NOTIFICATION, notification("Připravuji export…", 0, true), type);
        update("active", "Připravuji export…", 0, "");
        worker.execute(() -> {
            try {
                File[] stale = getCacheDir().listFiles((dir, name) -> name.startsWith("vid-export-")
                        && name.endsWith(".mp4"));
                if (stale != null) for (File file : stale) MediaFiles.remove(file);
                var preferences = getSharedPreferences(CHANNEL, MODE_PRIVATE);
                String staleRow = preferences.getString(PENDING_DOWNLOAD, "");
                if (!staleRow.isEmpty()) {
                    MediaFiles.deletePending(getContentResolver(), Uri.parse(staleRow));
                    preferences.edit().remove(PENDING_DOWNLOAD).commit();
                }
                light = bitmap(job.light);
                dark = bitmap(job.dark);
                MAIN.post(this::next);
            } catch (Exception e) {
                MAIN.post(() -> finish("error", readable(e)));
            }
        });
        return START_NOT_STICKY;
    }

    private void next() {
        if (cancelled.get()) { finish("cancelled", "Export zrušen."); return; }
        if (index >= job.media.size()) {
            String message = outputs.length() > 0 ? "Uloženo videí: " + outputs.length() + "."
                    : "Nepodařilo se uložit žádné video.";
            if (!errors.isEmpty()) message += " " + String.join(" · ", errors);
            finish(outputs.length() > 0 ? "done" : "error", message);
            return;
        }
        source = job.media.get(index);
        thermalRestarted = false;
        plan = null;
        forceStandard = !job.turbo;
        readSource();
    }

    private void readSource() {
        update("active", source.name + " · čtu informace o videu…", batchPercent(0), "");
        worker.execute(() -> {
            try {
                AdaptiveCodec.Video read = AdaptiveCodec.inspect(this, source.uri);
                MAIN.post(() -> {
                    if (cancelled.get()) return;
                    metadata = read;
                    startItem();
                });
            } catch (RuntimeException e) {
                MAIN.post(() -> itemError(e));
            }
        });
    }

    private void startItem() {
        if (cancelled.get()) return;
        thermalAtStart = AdaptiveCodec.thermal(this);
        if (thermalAtStart >= PowerManager.THERMAL_STATUS_CRITICAL) {
            finish("error", "Zařízení je příliš horké. Až vychladne, můžeš export zopakovat.");
            return;
        }
        try {
            plan = AdaptiveCodec.choose(metadata, job.fps, !forceStandard, thermalAtStart);
            detail = plan.detail();
            if (job.turbo && forceStandard) detail = "Standard · přepnuto po selhání Turbo"
                    + (thermalAtStart >= PowerManager.THERMAL_STATUS_MODERATE ? " · omezený výkon" : "");
            output = File.createTempFile("vid-export-", ".mp4", getCacheDir());
            if (!output.delete()) throw new IOException("Dočasný soubor nelze připravit.");
            if (getCacheDir().getUsableSpace() < 24 * 1024 * 1024L) throw new IOException("Málo místa pro export.");
            metrics = new StandardMuxer.Metrics();
            duration = job.limit > 0 ? Math.min(job.limit, metadata.duration()) : metadata.duration();
            ArrayList<Effect> effects = new ArrayList<>();
            if (plan.fps() + .05 < metadata.fps()) {
                effects.add(FrameDropEffect.createDefaultFrameDropEffect(plan.fps()));
            }
            if (plan.width() != metadata.width() || plan.height() != metadata.height()) {
                effects.add(Presentation.createForWidthAndHeight(plan.width(), plan.height(),
                        Presentation.LAYOUT_SCALE_TO_FIT));
            }
            effects.add(new WatermarkEffect(light, dark, new Motion(job.positions, job.motion,
                    job.minimum, job.maximum, job.seed), job.scale, job.opacity, job.color));
            MediaItem.Builder media = new MediaItem.Builder().setUri(source.uri);
            if (duration < metadata.duration()) media.setClippingConfiguration(
                    new MediaItem.ClippingConfiguration.Builder().setEndPositionMs(duration).build());
            EditedMediaItem edited = new EditedMediaItem.Builder(media.build())
                    .setEffects(new Effects(ImmutableList.of(), effects)).build();
            Composition composition = new Composition.Builder(new EditedMediaItemSequence.Builder(edited).build())
                    .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL).build();
            DefaultDecoderFactory.Builder decoder = new DefaultDecoderFactory.Builder(this)
                    .setEnableDecoderFallback(true);
            if (plan.turbo()) {
                decoder.setMediaCodecSelector((mime, secure, tunneling) ->
                        MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunneling).stream()
                                .filter(codec -> codec.hardwareAccelerated || !mime.startsWith("video/"))
                                .collect(java.util.stream.Collectors.toList()));
            }
            AdaptiveCodec.Plan activePlan = plan;
            DefaultEncoderFactory encoder = new DefaultEncoderFactory.Builder(this)
                    .setEnableFallback(!plan.turbo())
                    .setVideoEncoderSelector(mime -> activePlan.encoders())
                    .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder()
                            .setBitrate(AdaptiveCodec.bitrate(metadata, plan, job.quality)).build())
                    .build();
            transformer = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setAssetLoaderFactory(new DefaultAssetLoaderFactory(this, decoder.build(), Clock.DEFAULT))
                    .setEncoderFactory(new androidx.media3.transformer.Codec.EncoderFactory() {
                        @Override public androidx.media3.transformer.Codec createForAudioEncoding(
                                androidx.media3.common.Format format) throws ExportException {
                            return encoder.createForAudioEncoding(format);
                        }

                        @Override public androidx.media3.transformer.Codec createForVideoEncoding(
                                androidx.media3.common.Format format) throws ExportException {
                            return encoder.createForVideoEncoding(format.buildUpon()
                                    .setFrameRate(activePlan.fps()).build());
                        }

                        @Override public boolean videoNeedsEncoding() { return encoder.videoNeedsEncoding(); }
                        @Override public boolean audioNeedsEncoding() { return encoder.audioNeedsEncoding(); }
                    })
                    .setMuxerFactory(StandardMuxer.factory(metrics))
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition item, ExportResult result) {
                            transformer = null;
                            MAIN.removeCallbacks(monitor);
                            publish(result);
                        }

                        @Override public void onError(Composition item, ExportResult partial, ExportException e) {
                            transformer = null;
                            MAIN.removeCallbacks(monitor);
                            if (activePlan.turbo() && codecFailure(e)) {
                                MediaFiles.remove(output);
                                forceStandard = true;
                                startItem();
                            } else itemError(e);
                        }
                    }).build();
            started = SystemClock.elapsedRealtime();
            update("active", source.name + " · " + detail, batchPercent(0), encodingSettings());
            transformer.start(composition, output.getAbsolutePath());
            MAIN.removeCallbacks(monitor);
            MAIN.postDelayed(monitor, 650);
        } catch (RuntimeException | IOException e) {
            if (transformer != null) transformer.cancel();
            transformer = null;
            if (plan != null && plan.turbo() && e instanceof IllegalStateException) {
                MediaFiles.remove(output);
                forceStandard = true;
                startItem();
            } else itemError(e);
        }
    }

    private String encodingSettings() {
        return plan.width() + " × " + plan.height() + " · " + Math.round(plan.fps()) + " FPS zdroje/max.";
    }

    private void showProgress() {
        if (transformer == null || cancelled.get()) return;
        int thermal = AdaptiveCodec.thermal(this);
        if (thermal >= PowerManager.THERMAL_STATUS_CRITICAL) {
            cancelled.set(true);
            transformer.cancel();
            transformer = null;
            MediaFiles.remove(output);
            finish("error", "Export zastaven kvůli vysoké teplotě zařízení.");
            return;
        }
        if (thermalAtStart < PowerManager.THERMAL_STATUS_MODERATE
                && thermal >= PowerManager.THERMAL_STATUS_SEVERE && !thermalRestarted
                && (plan.width() > 1920 || plan.height() > 1920 || plan.fps() > 30)) {
            thermalRestarted = true;
            transformer.cancel();
            transformer = null;
            MediaFiles.remove(output);
            startItem();
            return;
        }
        double elapsed = Math.max(.01, (SystemClock.elapsedRealtime() - started) / 1000.0);
        double seconds = Math.min(duration / 1000.0, metrics.latestUs.get() / 1_000_000.0);
        double speed = seconds / elapsed;
        String performance = encodingSettings();
        if (metrics.frames.get() > 0) {
            performance += String.format(java.util.Locale.ROOT, " · %.2f× · %.1f sn./s exportu",
                    speed, metrics.frames.get() / elapsed);
            if (speed > .001) performance += " · zbývá přibližně "
                    + (long) Math.ceil(Math.max(0, duration / 1000.0 - seconds) / speed) + " s";
        }
        int result = transformer.getProgress(progressHolder);
        int percent = result == Transformer.PROGRESS_STATE_AVAILABLE ? progressHolder.progress
                : (int) Math.min(99, 100000 * seconds / duration);
        update("active", source.name + " · " + detail, batchPercent(percent), performance);
        MAIN.postDelayed(monitor, 750);
    }

    private void publish(ExportResult result) {
        if (result.videoFrameCount < 1) { itemError(new IOException("Výstup neobsahuje snímky.")); return; }
        update("active", source.name + " · ukládám MP4…", batchPercent(99), "");
        File finishedFile = output;
        Job active = job;
        String sourceName = source.name;
        var preferences = getSharedPreferences(CHANNEL, MODE_PRIVATE);
        worker.execute(() -> {
            Uri row = null;
            try {
                if (cancelled.get()) return;
                String name = sourceName.replaceFirst("\\.[^.]+$", "").replaceAll("[^\\p{L}\\p{N} _.-]", "_");
                if (name.isBlank()) name = "Video";
                if (name.length() > 80) name = name.substring(0, 80);
                name += active.limit > 0 ? "-Bubble-Preview.mp4" : "-Bubble-VidAI.mp4";
                row = MediaFiles.openDownload(this, name, "video/mp4");
                preferences.edit().putString(PENDING_DOWNLOAD, row.toString()).commit();
                try (var in = Files.newInputStream(finishedFile.toPath());
                     OutputStream out = getContentResolver().openOutputStream(row)) {
                    if (out == null) throw new IOException("Úložiště není dostupné.");
                    byte[] buffer = new byte[131072];
                    for (int bytes; !cancelled.get() && (bytes = in.read(buffer)) != -1;) {
                        out.write(buffer, 0, bytes);
                    }
                }
                if (cancelled.get()) return;
                MediaFiles.publish(getContentResolver(), row);
                JSONObject saved = new JSONObject().put("name", name).put("uri", row.toString())
                        .put("encoder", result.videoEncoderName).put("frames", result.videoFrameCount);
                row = null;
                MAIN.post(() -> {
                    if (job != active) return;
                    outputs.put(saved);
                    index++;
                    next();
                });
            } catch (Exception e) {
                MAIN.post(() -> itemError(e));
            } finally {
                MediaFiles.delete(getContentResolver(), row);
                preferences.edit().remove(PENDING_DOWNLOAD).commit();
                MediaFiles.remove(finishedFile);
                if (cancelled.get()) MAIN.post(() -> finish("cancelled", "Export zrušen."));
            }
        });
    }

    private void itemError(Exception error) {
        if (job == null || cancelled.get()) return;
        Log.w("VidAI", "Export failed", error);
        MediaFiles.remove(output);
        errors.add(source.name + ": " + readable(error));
        index++;
        next();
    }

    private static boolean codecFailure(ExportException e) {
        return e.errorCode >= 3000 && e.errorCode < 5000;
    }

    private int batchPercent(int value) {
        return (index * 100 + value) / job.media.size();
    }

    private void cancelExport() {
        if (job == null) return;
        cancelled.set(true);
        MAIN.removeCallbacks(monitor);
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        worker.execute(() -> {
            MediaFiles.remove(output);
            MAIN.post(() -> finish("cancelled", "Export zrušen."));
        });
    }

    @Override public void onTimeout(int startId, int foregroundServiceType) {
        cancelExport();
        finish("error", "Android ukončil časový limit exportu na pozadí.");
    }

    private void finish(String status, String message) {
        if (job == null) return;
        MAIN.removeCallbacks(monitor);
        int percent = "done".equals(status) ? 100 : batchPercent(0);
        update(status, message, percent, "");
        job = null;
        stopForeground(STOP_FOREGROUND_REMOVE);
        if (!"cancelled".equals(status)) {
            getSystemService(NotificationManager.class).notify(RESULT_NOTIFICATION,
                    notification(message, percent, false));
        }
        stopSelf();
    }

    @Override public void onDestroy() {
        MAIN.removeCallbacks(monitor);
        cancelled.set(true);
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        if (job != null) {
            update("error", "Export byl přerušen. Projekt zůstal uložený.", batchPercent(0), "");
        }
        worker.execute(() -> MediaFiles.remove(output));
        worker.shutdown();
        if (current == this) current = null;
        super.onDestroy();
    }

    private void update(String phase, String message, int percent, String performance) {
        snapshot = state(job.id, phase, message, percent, performance, outputs).toString();
        if (phase.equals("active")) {
            getSystemService(NotificationManager.class).notify(NOTIFICATION, notification(message, percent, true));
            getSharedPreferences(CHANNEL, MODE_PRIVATE).edit().putString("status",
                    state(job.id, "error", "Export byl přerušen. Projekt zůstal uložený.", percent,
                            "", outputs).toString()).apply();
        } else getSharedPreferences(CHANNEL, MODE_PRIVATE).edit().putString("status", snapshot).apply();
    }

    private Notification notification(String description, int progress, boolean ongoing) {
        PendingIntent launch = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder notice = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Bubble VidAI").setContentText(description)
                .setStyle(new Notification.BigTextStyle().bigText(description))
                .setContentIntent(launch).setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing);
        if (ongoing) {
            PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, ExportService.class).setAction(CANCEL),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            notice.setProgress(100, progress, progress == 0);
            notice.addAction(new Notification.Action.Builder(null, "Zrušit", stop).build());
        }
        return notice.build();
    }

    private static JSONObject state(String id, String status, String message, int percent, String perf, JSONArray results) {
        JSONObject row = new JSONObject();
        try {
            row.put("id", id).put("phase", status).put("message", message).put("progress", percent)
                    .put("performance", perf).put("outputs", results);
        } catch (JSONException ignored) {}
        return row;
    }

    private static String readable(Exception e) {
        if (e instanceof ExportException error) return "Kódování selhalo (" + error.getErrorCodeName() + ").";
        String message = e.getLocalizedMessage();
        return message == null ? "Export se nezdařil." : message;
    }

    private static Bitmap bitmap(String data) throws IOException {
        byte[] png = Base64.decode(data, Base64.DEFAULT);
        Bitmap value = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (value == null || value.getWidth() > 4096 || value.getHeight() > 256) {
            throw new IOException("Vodoznak nelze načíst.");
        }
        return value;
    }

    private record Media(Uri uri, String name) {}

    private static final class Job {
        final List<Media> media = new ArrayList<>();
        final String id, light, dark, motion, quality;
        final long limit;
        final int fps, seed, color;
        final int[] positions;
        final double minimum, maximum;
        final float scale, opacity;
        final boolean turbo;

        Job(JSONObject json) throws JSONException {
            id = json.getString("id");
            JSONArray list = json.getJSONArray("media");
            if (list.length() < 1 || list.length() > 250) throw new JSONException("Vyber 1 až 250 videí.");
            for (int i = 0; i < list.length(); i++) {
                JSONObject item = list.getJSONObject(i);
                Uri uri = Uri.parse(item.getString("uri"));
                if (!"content".equals(uri.getScheme())) throw new JSONException("Neplatný zdroj videa.");
                media.add(new Media(uri, item.getString("name")));
            }
            light = json.getString("light");
            dark = json.getString("dark");
            motion = json.getString("motion");
            quality = json.getString("quality");
            turbo = json.getBoolean("turbo");
            limit = Math.max(0, json.getLong("limit"));
            fps = json.getInt("fps");
            seed = json.getInt("seed");
            color = json.getInt("color");
            scale = (float) json.getDouble("scale");
            opacity = (float) json.getDouble("opacity");
            minimum = Math.max(1, Math.min(60, json.getDouble("min")));
            maximum = Math.max(minimum, Math.min(60, json.getDouble("max")));
            JSONArray grid = json.getJSONArray("positions");
            if (grid.length() < 1 || grid.length() > 9) throw new JSONException("Vyber pozici vodoznaku.");
            positions = new int[grid.length()];
            for (int i = 0; i < positions.length; i++) {
                positions[i] = grid.getInt(i);
                if (positions[i] < 0 || positions[i] > 8) throw new JSONException("Neplatná pozice.");
            }
        }
    }
}
