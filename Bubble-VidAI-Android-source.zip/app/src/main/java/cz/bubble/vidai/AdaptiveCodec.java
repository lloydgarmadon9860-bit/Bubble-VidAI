package cz.bubble.vidai;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import android.content.Context;
import android.media.MediaCodecInfo;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.PowerManager;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.EncoderUtil;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.List;

@OptIn(markerClass = UnstableApi.class)
final class AdaptiveCodec {
    record Video(int width, int height, double fps, long duration, int bitrate) {}
    record Plan(int width, int height, float fps, boolean turbo,
                ImmutableList<MediaCodecInfo> encoders, String detail) {}

    static Video inspect(Context context, Uri uri) {
        try (MediaMetadataRetriever reader = new MediaMetadataRetriever()) {
            reader.setDataSource(context, uri);
            int width = (int) number(reader, MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            int height = (int) number(reader, MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            int rotation = (int) number(reader, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if (rotation == 90 || rotation == 270) {
                int sideways = width;
                width = height;
                height = sideways;
            }
            long duration = (long) number(reader, MediaMetadataRetriever.METADATA_KEY_DURATION);
            double frames = number(reader, MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT);
            double fps = frames > 0 && duration > 0 ? 1000 * frames / duration
                    : number(reader, MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE);
            if (width < 2 || height < 2 || duration < 1) throw new IllegalArgumentException("Video nelze načíst.");
            return new Video(width, height, fps >= 1 ? fps : 30, duration,
                    (int) number(reader, MediaMetadataRetriever.METADATA_KEY_BITRATE));
        } catch (java.io.IOException e) {
            throw new IllegalArgumentException("Video nelze načíst.", e);
        }
    }

    static int thermal(Context context) {
        return context.getSystemService(PowerManager.class).getCurrentThermalStatus();
    }

    static Plan choose(Video source, int fpsLimit, boolean wantsTurbo, int thermal) {
        float requestedFps = (float) Math.min(source.fps, fpsLimit <= 0 ? source.fps : fpsLimit);
        boolean warm = thermal >= PowerManager.THERMAL_STATUS_MODERATE;
        int top = warm ? 1920 : Math.max(source.width, source.height);
        float topFps = Math.min(requestedFps, warm ? 30 : requestedFps);
        int[] limits = {top, 1920, 1280, 854, 640};
        List<MediaCodecInfo> all = EncoderUtil.getSupportedEncoders(MimeTypes.VIDEO_H264);
        for (int limit : limits) {
            if (limit > top) continue;
            float scale = Math.min(1f, (float) limit / Math.max(source.width, source.height));
            int width = Math.max(2, Math.round(source.width * scale / 2) * 2);
            int height = Math.max(2, Math.round(source.height * scale / 2) * 2);
            for (float fps : new float[]{topFps, Math.min(30, topFps), Math.min(24, topFps)}) {
                ArrayList<MediaCodecInfo> hardware = new ArrayList<>(), standard = new ArrayList<>();
                for (MediaCodecInfo codec : all) {
                    if (!supports(codec, width, height, fps)) continue;
                    (codec.isHardwareAccelerated() ? hardware : standard).add(codec);
                }
                boolean turbo = wantsTurbo && !hardware.isEmpty();
                if (turbo || !standard.isEmpty() || !hardware.isEmpty()) {
                    ArrayList<MediaCodecInfo> candidates = new ArrayList<>(hardware);
                    if (!turbo) candidates.addAll(standard);
                    String detail = turbo ? "Turbo · hardwarový enkodér" : wantsTurbo
                            ? "Standard · použitelný enkodér Turbo chybí" : "Standard";
                    if (warm) detail += " · omezený výkon kvůli teplotě";
                    else if (width != source.width || height != source.height || fps + .05 < requestedFps) {
                        detail += " · upraveno podle schopností zařízení";
                    }
                    return new Plan(width, height, fps, turbo, ImmutableList.copyOf(candidates), detail);
                }
            }
        }
        throw new IllegalArgumentException("Zařízení nemá dostupný enkodér H.264.");
    }

    static int bitrate(Video video, Plan plan, String quality) {
        double ratio = (double) plan.width * plan.height / ((double) video.width * video.height)
                * Math.min(1, plan.fps / video.fps);
        double base = video.bitrate > 0 ? video.bitrate : (double) video.width * video.height * video.fps * .14;
        double factor = switch (quality) {
            case "max" -> 1.65;
            case "balanced" -> .78;
            case "small" -> .42;
            default -> 1;
        };
        return (int) Math.max(250_000, Math.min(120_000_000, base * ratio * factor));
    }

    private static boolean supports(MediaCodecInfo codec, int width, int height, double fps) {
        try {
            MediaCodecInfo.CodecCapabilities caps = codec.getCapabilitiesForType(MimeTypes.VIDEO_H264);
            return (caps.getVideoCapabilities().areSizeAndRateSupported(width, height, fps)
                    || caps.getVideoCapabilities().areSizeAndRateSupported(height, width, fps))
                    && java.util.Arrays.stream(caps.colorFormats)
                    .anyMatch(format -> format == MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static double number(MediaMetadataRetriever reader, int field) {
        try { return Double.parseDouble(reader.extractMetadata(field)); }
        catch (NumberFormatException | NullPointerException e) { return 0; }
    }
}
