package cz.bubble.vidai;

record ByteRange(long start, long end) {
    long length() { return end - start + 1; }

    static ByteRange parse(String value, long size) {
        if (size <= 0 || !value.startsWith("bytes=") || value.contains(",")) return null;
        String[] bounds = value.substring(6).split("-", -1);
        if (bounds.length != 2) return null;
        try {
            if (bounds[0].isEmpty()) {
                long length = Long.parseLong(bounds[1]);
                return length <= 0 ? null : new ByteRange(Math.max(0, size - length), size - 1);
            }
            long from = Long.parseLong(bounds[0]);
            long to = bounds[1].isEmpty() ? size - 1 : Math.min(size - 1, Long.parseLong(bounds[1]));
            return from < 0 || from > to ? null : new ByteRange(from, to);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
