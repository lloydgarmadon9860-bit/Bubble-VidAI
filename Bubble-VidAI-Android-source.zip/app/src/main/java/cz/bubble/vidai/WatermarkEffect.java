package cz.bubble.vidai;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLES20;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

@OptIn(markerClass = UnstableApi.class)
final class WatermarkEffect implements GlEffect {
    private static final String VERTEX = """
        attribute vec4 position;
        varying vec2 uv;
        void main() {
            gl_Position = position;
            uv = position.xy * 0.5 + 0.5;
        }
        """;

    private static final String FRAGMENT = """
        precision highp float;
        uniform sampler2D video;
        uniform sampler2D lightMark;
        uniform sampler2D darkMark;
        uniform vec4 box;
        uniform float opacity;
        uniform int colorMode;
        varying vec2 uv;

        float luminance(vec2 place) {
            vec3 rgb = texture2D(video, box.xy + place * box.zw).rgb;
            return dot(rgb, vec3(0.2126, 0.7152, 0.0722));
        }

        void main() {
            vec4 base = texture2D(video, uv);
            vec2 local = (uv - box.xy) / box.zw;
            if (local.x < 0.0 || local.x > 1.0 || local.y < 0.0 || local.y > 1.0) {
                gl_FragColor = base;
                return;
            }
            bool dark = colorMode == 2;
            if (colorMode == 0) {
                float lum = 0.0;
                for (int y = 0; y < 3; y++) {
                    for (int x = 0; x < 3; x++) {
                        lum += luminance(vec2(float(x) + 0.5, float(y) + 0.5) / 3.0);
                    }
                }
                dark = lum / 9.0 > 0.45;
            }
            vec2 markUv = vec2(local.x, 1.0 - local.y);
            vec4 mark = dark ? texture2D(darkMark, markUv) : texture2D(lightMark, markUv);
            gl_FragColor = vec4(base.rgb * (1.0 - mark.a * opacity) + mark.rgb * opacity, base.a);
        }
        """;

    private final Bitmap light, dark;
    private final Motion motion;
    private final float scale, opacity;
    private final int colorMode;

    WatermarkEffect(Bitmap light, Bitmap dark, Motion motion, float scale, float opacity, int colorMode) {
        this.light = light;
        this.dark = dark;
        this.motion = motion;
        this.scale = scale;
        this.opacity = opacity;
        this.colorMode = colorMode;
    }

    @Override public GlShaderProgram toGlShaderProgram(Context context, boolean hdr)
            throws VideoFrameProcessingException {
        try {
            return new Program(hdr);
        } catch (GlUtil.GlException e) {
            throw new VideoFrameProcessingException(e);
        }
    }

    private final class Program extends BaseGlShaderProgram {
        private final GlProgram gl;
        private final int lightTexture, darkTexture;
        private final float[] box = new float[4];
        private int width, height;
        private long firstTime = Long.MIN_VALUE;
        private float markWidth, markHeight, margin;

        Program(boolean hdr) throws GlUtil.GlException {
            super(hdr, 1);
            gl = new GlProgram(VERTEX, FRAGMENT);
            gl.setBufferAttribute("position", GlUtil.getNormalizedCoordinateBounds(), 4);
            lightTexture = GlUtil.createTexture(light);
            darkTexture = GlUtil.createTexture(dark);
        }

        @Override public Size configure(int inputWidth, int inputHeight) {
            width = inputWidth;
            height = inputHeight;
            float shortSide = Math.min(width, height);
            margin = shortSide * .035f;
            float factor = Math.min(shortSide * .055f * scale / 128f, (width - margin * 2) / light.getWidth());
            markWidth = light.getWidth() * factor;
            markHeight = light.getHeight() * factor;
            return new Size(width, height);
        }

        @Override public void drawFrame(int inputTexId, long timeUs) throws VideoFrameProcessingException {
            if (firstTime == Long.MIN_VALUE) firstTime = timeUs;
            Motion.Pose pose = motion.at((timeUs - firstTime) / 1_000_000.0);
            float x0 = coordinate(pose.before() % 3, width, markWidth);
            float y0 = coordinate(pose.before() / 3, height, markHeight);
            float x = x0 + (coordinate(pose.after() % 3, width, markWidth) - x0) * pose.mix();
            float y = y0 + (coordinate(pose.after() / 3, height, markHeight) - y0) * pose.mix();
            box[0] = x / width;
            box[1] = 1 - (y + markHeight) / height;
            box[2] = markWidth / width;
            box[3] = markHeight / height;
            try {
                gl.use();
                gl.setSamplerTexIdUniform("video", inputTexId, 0);
                gl.setSamplerTexIdUniform("lightMark", lightTexture, 1);
                gl.setSamplerTexIdUniform("darkMark", darkTexture, 2);
                gl.setFloatsUniform("box", box);
                gl.setFloatUniform("opacity", opacity * pose.alpha());
                gl.setIntUniform("colorMode", colorMode);
                gl.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
                GlUtil.checkGlError();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, timeUs);
            }
        }

        private float coordinate(int grid, int length, float span) {
            return margin + grid * (length - span - 2 * margin) / 2;
        }

        @Override public boolean shouldClearTextureBuffer() { return false; }

        @Override public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                GlUtil.deleteTexture(lightTexture);
                GlUtil.deleteTexture(darkTexture);
                gl.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }
    }
}
