package cz.bubble.vidai;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.IOException;

final class MediaFiles {
    private MediaFiles() {}

    static Uri openDownload(Context context, String name, String mime) throws IOException {
        ContentValues row = new ContentValues();
        row.put(MediaStore.Downloads.DISPLAY_NAME, name);
        row.put(MediaStore.Downloads.MIME_TYPE, mime);
        row.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Bubble VidAI");
        row.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, row);
        if (uri == null) throw new IOException("Stažené soubory nejsou dostupné.");
        return uri;
    }

    static void publish(ContentResolver resolver, Uri uri) throws IOException {
        ContentValues row = new ContentValues();
        row.put(MediaStore.Downloads.IS_PENDING, 0);
        if (resolver.update(uri, row, null, null) != 1) throw new IOException("Video se nepodařilo uložit.");
    }

    static void delete(ContentResolver resolver, Uri uri) {
        try {
            if (uri != null) resolver.delete(uri, null, null);
        } catch (RuntimeException ignored) {}
    }

    static void deletePending(ContentResolver resolver, Uri uri) {
        try (var cursor = resolver.query(uri, new String[]{MediaStore.Downloads.IS_PENDING}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 1) delete(resolver, uri);
        } catch (RuntimeException ignored) {}
    }

    static boolean remove(File file) {
        return file == null || !file.exists() || file.delete();
    }
}
